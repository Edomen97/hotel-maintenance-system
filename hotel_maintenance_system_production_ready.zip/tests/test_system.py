import os, secrets
from pathlib import Path
os.environ['TESTING']='true'
os.environ['APP_SECRET']=secrets.token_urlsafe(48)
os.environ['DATABASE_URL']='sqlite:///./test_hotel_maintenance.db'
os.environ['SESSION_HTTPS_ONLY']='false'
os.environ['BOOTSTRAP_ADMIN_USERNAME']='bootstrap-admin'
os.environ['BOOTSTRAP_ADMIN_PASSWORD']=secrets.token_urlsafe(24)

from fastapi.testclient import TestClient
from app.db import engine, SessionLocal
from app.models import Base, Room, Floor, User, MaintenanceRequest, WorkOrder, InventoryItem, AuditLog, QRCode, Notification
from app.security import hash_password, verify_password
from app.main import app, seed

Base.metadata.drop_all(engine); Base.metadata.create_all(engine); seed()

PASSWORDS={role:secrets.token_urlsafe(18) for role in ['MANAGER','MAINTENANCE STAFF','EMPLOYEE']}
with SessionLocal() as db:
    db.add_all([
        User(username='manager-test',full_name='Manager',password_hash=hash_password(PASSWORDS['MANAGER']),role='MANAGER'),
        User(username='staff-test',full_name='Staff',password_hash=hash_password(PASSWORDS['MAINTENANCE STAFF']),role='MAINTENANCE STAFF'),
        User(username='employee-test',full_name='Employee',password_hash=hash_password(PASSWORDS['EMPLOYEE']),role='EMPLOYEE'),
    ]); db.commit()

client=TestClient(app)

def login(username,password): return client.post('/login',data={'username':username,'password':password},follow_redirects=False)
def logout(): client.post('/logout')
def user_row(role):
    with SessionLocal() as db:return db.query(User).filter_by(role=role).first()

def test_rooms_exactly_201_300_and_floor_relationships():
    with SessionLocal() as db:
        rooms=db.query(Room).order_by(Room.room_number).all(); assert len(rooms)==100
        assert [r.room_number for r in rooms]==list(range(201,301))
        assert len({r.room_number for r in rooms})==100
        mapping={n:2+(n-201)//25 for n in range(201,301)}
        assert {r.room_number:r.floor.number for r in rooms}==mapping
        assert all(r.floor.number in {2,3,4,5} for r in rooms)

def test_authentication_and_role_permissions():
    assert login('employee-test',PASSWORDS['EMPLOYEE']).status_code==303
    assert client.get('/admin').status_code==403
    assert client.post('/admin/room-status/1',data={'status':'Maintenance','reason':'x'}).status_code==403
    assert client.post('/requests/1/approve').status_code==403
    logout()
    assert login('manager-test',PASSWORDS['MANAGER']).status_code==303
    assert client.get('/audit').status_code==403
    logout()
    assert login('staff-test',PASSWORDS['MAINTENANCE STAFF']).status_code==303
    assert client.get('/admin').status_code==403
    logout()

def test_request_validation_sla_and_work_order_workflow():
    assert login('employee-test',PASSWORDS['EMPLOYEE']).status_code==303
    with SessionLocal() as db:
        room=db.query(Room).filter_by(room_number=230).one(); wi=db.query(__import__('app.models',fromlist=['WorkingItem']).WorkingItem).first(); cat=db.query(__import__('app.models',fromlist=['Category']).Category).first()
    bad=client.post('/requests/create',data={'location_type':'Room','room_id':999999,'working_item_id':wi.id,'category_id':cat.id,'problem':'bad','priority':'LOW'}); assert bad.status_code==400
    ok=client.post('/requests/create',data={'location_type':'Room','room_id':room.id,'working_item_id':wi.id,'category_id':cat.id,'problem':'AC failed inspection','priority':'URGENT'},follow_redirects=False); assert ok.status_code==303
    with SessionLocal() as db:
        req=db.query(MaintenanceRequest).order_by(MaintenanceRequest.id.desc()).first(); assert req.room_id==room.id; assert req.floor_id==room.floor_id; assert req.due_at-req.created_at <= __import__('datetime').timedelta(hours=1,seconds=2)
    logout(); login('manager-test',PASSWORDS['MANAGER'])
    assert client.post(f'/requests/{req.id}/approve',follow_redirects=False).status_code==303
    with SessionLocal() as db:
        wo=db.query(WorkOrder).filter_by(request_id=req.id).one(); staff=user_row('MAINTENANCE STAFF'); part=db.query(InventoryItem).first(); original=part.quantity
    assert client.post(f'/work-orders/{wo.id}/assign',data={'staff_id':staff.id},follow_redirects=False).status_code==303
    logout(); login('staff-test',PASSWORDS['MAINTENANCE STAFF'])
    assert client.post(f'/work-orders/{wo.id}/status',data={'status':'In Progress','work_performed':'Started','labor_hours':'1'},follow_redirects=False).status_code==303
    assert client.post(f'/work-orders/{wo.id}/parts',data={'part_id':part.id,'quantity':'1'},follow_redirects=False).status_code==303
    assert client.post(f'/work-orders/{wo.id}/status',data={'status':'Completed','work_performed':'Repaired','completion_notes':'Done','labor_hours':'2'},follow_redirects=False).status_code==303
    logout(); login('manager-test',PASSWORDS['MANAGER'])
    assert client.post(f'/work-orders/{wo.id}/verify',data={'passed':'yes'},follow_redirects=False).status_code==303
    with SessionLocal() as db:
        refreshed=db.get(MaintenanceRequest,req.id); p=db.get(InventoryItem,part.id)
        assert refreshed.status=='Closed'; assert p.quantity==original-1
        assert db.query(AuditLog).filter_by(object_type='WorkOrder',object_id=str(wo.id)).count()>=3

def test_qr_mapping_and_notifications():
    with SessionLocal() as db:
        qr=db.query(QRCode).filter_by(code='ROOM-230').one(); assert qr.room_id is not None and qr.area_id is None
        room=db.get(Room,qr.room_id); assert room.room_number==230
        area_qr=db.query(QRCode).filter(QRCode.code.like('AREA-%')).first(); assert area_qr.area_id is not None and area_qr.room_id is None
    logout(); login('employee-test',PASSWORDS['EMPLOYEE'])
    assert client.get('/qr/ROOM-230',follow_redirects=False).status_code==303
    page=client.get('/requests'); assert page.status_code==200 and 'Room 230' in page.text

def test_file_upload_security():
    logout(); login('employee-test',PASSWORDS['EMPLOYEE'])
    with SessionLocal() as db: wo=db.query(WorkOrder).first()
    assert client.post(f'/upload/{wo.id}',files={'file':('evil.exe',b'MZ'+b'x'*20,'application/octet-stream')},data={'kind':'Evidence'}).status_code==403
    logout(); login('staff-test',PASSWORDS['MAINTENANCE STAFF'])
    r=client.post(f'/upload/{wo.id}',files={'file':('fake.jpg',b'not-an-image','image/jpeg')},data={'kind':'Before Photo'}); assert r.status_code==400

def test_low_stock_alert_and_dashboard():
    logout(); login('manager-test',PASSWORDS['MANAGER'])
    with SessionLocal() as db:
        part=db.query(InventoryItem).first(); wo=db.query(WorkOrder).first(); staff=user_row('MAINTENANCE STAFF'); part.quantity=1; part.minimum_stock=1; db.commit()
    logout(); login('staff-test',PASSWORDS['MAINTENANCE STAFF'])
    client.post(f'/work-orders/{wo.id}/parts',data={'part_id':part.id,'quantity':'1'},follow_redirects=False)
    with SessionLocal() as db:
        p=db.get(InventoryItem,part.id); assert p.quantity==0
        assert db.query(Notification).filter(Notification.type=='LOW_STOCK').count()>=1
    assert client.get('/').status_code==200

def test_offline_queue_api_is_idempotent():
    logout(); login('employee-test',PASSWORDS['EMPLOYEE'])
    with SessionLocal() as db:
        room=db.query(Room).filter_by(room_number=231).one(); wi=db.query(__import__('app.models',fromlist=['WorkingItem']).WorkingItem).first(); cat=db.query(__import__('app.models',fromlist=['Category']).Category).first()
    payload={'client_request_id':'offline-'+secrets.token_hex(8),'location_type':'Room','room_id':room.id,'working_item_id':wi.id,'category_id':cat.id,'problem':'Offline queued request','priority':'MEDIUM'}
    headers={'X-Offline-Queue':'1'}
    r1=client.post('/api/requests',json=payload,headers=headers); r2=client.post('/api/requests',json=payload,headers=headers)
    assert r1.status_code==200 and r2.status_code==200
    with SessionLocal() as db: assert db.query(MaintenanceRequest).filter_by(client_request_id=payload['client_request_id']).count()==1

def test_backup_endpoint_admin_only():
    logout(); login('employee-test',PASSWORDS['EMPLOYEE']); assert client.post('/backup').status_code==403
    logout(); login('bootstrap-admin',os.environ['BOOTSTRAP_ADMIN_PASSWORD']); r=client.post('/backup',follow_redirects=False); assert r.status_code==303
    assert any(Path('backups').glob('*.db'))

def test_migration_metadata_present():
    import subprocess, tempfile
    db_path=Path(tempfile.mkstemp(suffix='.db')[1]); env=os.environ.copy(); env['DATABASE_URL']=f'sqlite:///{db_path}'
    subprocess.run(['alembic','upgrade','head'],env=env,cwd=Path(__file__).resolve().parents[1],check=True,capture_output=True,text=True)
    import sqlite3
    con=sqlite3.connect(db_path); version=con.execute('select version_num from alembic_version').fetchone(); con.close(); db_path.unlink(missing_ok=True)
    assert version and version[0]=='72c9335ab02e'
