from datetime import datetime, timedelta, timezone
from sqlalchemy import select
from .models import *

SLA={'URGENT':timedelta(hours=1),'HIGH':timedelta(hours=4),'MEDIUM':timedelta(hours=24),'LOW':timedelta(hours=72)}

def utcnow(): return datetime.now(timezone.utc).replace(tzinfo=None)
def sla_due(priority, created=None):
    priority=priority.upper()
    if priority not in SLA: raise ValueError('Invalid priority')
    return (created or utcnow()) + SLA[priority]

def audit(db,user,action,obj_type,obj_id,old='',new='',ip=''):
    db.add(AuditLog(user_id=getattr(user,'id',None),action=action,object_type=obj_type,object_id=str(obj_id),old_value=str(old),new_value=str(new),ip=ip or '')); db.flush()

def _push(user_id,message,typ):
    if not all([__import__('os').getenv('VAPID_PRIVATE_KEY'),__import__('os').getenv('VAPID_PUBLIC_KEY'),__import__('os').getenv('VAPID_CLAIMS_EMAIL')]): return
    try:
        from pywebpush import webpush, WebPushException
        from .db import SessionLocal
        s=SessionLocal()
        try:
            subs=s.scalars(select(PushSubscription).where(PushSubscription.user_id==user_id)).all()
            payload={'title':'Hotel Maintenance','body':message[:200],'url':'/notifications','type':typ}
            for sub in subs:
                try: webpush(subscription_info={'endpoint':sub.endpoint,'keys':{'p256dh':sub.p256dh,'auth':sub.auth}},data=__import__('json').dumps(payload),vapid_private_key=__import__('os').environ['VAPID_PRIVATE_KEY'],vapid_claims={'sub':__import__('os').environ['VAPID_CLAIMS_EMAIL']})
                except WebPushException as exc:
                    if getattr(exc,'response',None) is not None and exc.response.status_code in (404,410): s.delete(sub)
            s.commit()
        finally: s.close()
    except ImportError: pass

def notify_roles(db,roles,message,typ,request_id=None,work_order_id=None):
    users=db.scalars(select(User).where(User.role.in_(roles),User.active.is_(True))).all()
    for u in users:
        db.add(Notification(user_id=u.id,message=message[:500],type=typ,request_id=request_id,work_order_id=work_order_id)); db.flush(); _push(u.id,message,typ)

def record_request_status(db,request,old_status,new_status,user,note=''):
    if old_status==new_status:return
    request.status=new_status; db.add(RequestStatusHistory(request_id=request.id,old_status=old_status or '',new_status=new_status,changed_by_id=user.id,note=note)); audit(db,user,'STATUS_CHANGE','MaintenanceRequest',request.id,old=old_status,new=new_status)

def recalc_inventory(db,part,qty,user,work_order=None,request=None,reason='Used'):
    if qty<=0: raise ValueError('Quantity must be greater than zero')
    if part.quantity<qty: raise ValueError('Insufficient stock')
    part.quantity-=qty
    db.add(StockMovement(part_id=part.id,direction='OUT',quantity=qty,user_id=user.id,work_order_id=getattr(work_order,'id',None),request_id=getattr(request,'id',None),reason=reason))
    if work_order is not None:
        db.add(Cost(request_id=getattr(request,'id',None),work_order_id=work_order.id,parts_cost=round(qty*part.unit_cost,2)))
    if part.quantity<=part.minimum_stock: notify_roles(db,['ADMIN','MANAGER'],f'Low stock: {part.part_name} ({part.quantity:g} {part.unit})','LOW_STOCK')
    return part.quantity
