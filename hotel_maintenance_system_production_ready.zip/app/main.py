import csv
import io
import json
import mimetypes
import os
import re
import secrets
import shutil
import sqlite3
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path

from fastapi import FastAPI, Request, Form, UploadFile, File, HTTPException, Depends
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from sqlalchemy import select, func, desc
from sqlalchemy.orm import Session

from .db import SessionLocal, engine
from .models import *
from .security import hash_password, verify_password
from .services import sla_due, audit, notify_roles, recalc_inventory, record_request_status, utcnow

BASE=Path(__file__).resolve().parent.parent
UPLOADS=BASE/'uploads'; BACKUPS=BASE/'backups'
UPLOADS.mkdir(exist_ok=True); BACKUPS.mkdir(exist_ok=True)
APP_SECRET=os.getenv('APP_SECRET','').strip()
if len(APP_SECRET)<32:
    raise RuntimeError('APP_SECRET must be set and contain at least 32 characters.')

app=FastAPI(title='Hotel Maintenance Management System',version='2.0.0')
app.add_middleware(SessionMiddleware, secret_key=APP_SECRET, max_age=60*60*12, same_site='lax', https_only=os.getenv('SESSION_HTTPS_ONLY','true').lower()=='true')
app.mount('/static',StaticFiles(directory=str(BASE/'app/static')),name='static')
templates=Jinja2Templates(directory=str(BASE/'app/templates'))

SAFE_METHODS={'GET','HEAD','OPTIONS'}
ROLE_VALUES={'ADMIN','MANAGER','MAINTENANCE STAFF','EMPLOYEE'}
PRIORITIES={'URGENT','HIGH','MEDIUM','LOW'}
STATUSES={'Pending','Approved','Assigned','In Progress','Completed','Verified','Closed','Cancelled','Overdue'}
ROOM_STATUSES={'Available','Occupied','Reserved','Maintenance','Out of Service'}
ALLOWED_FREQUENCIES={'Daily','Weekly','Monthly','Quarterly','Yearly'}
ALLOWED_FILE_KINDS={'Before Photo','During Repair Photo','After Photo','Invoice','Quotation','Work Order PDF','Inspection Report','Service Report','Warranty Document','Evidence'}
MAX_UPLOAD=10*1024*1024
LOGIN_WINDOW=300
LOGIN_MAX=8
login_attempts={}

@app.middleware('http')
async def security_headers_and_csrf(request:Request, call_next):
    if request.method not in SAFE_METHODS and os.getenv('TESTING','false').lower()!='true':
        origin=request.headers.get('origin')
        referer=request.headers.get('referer')
        host=request.headers.get('host','')
        valid=(origin and origin.split('://',1)[-1].split('/',1)[0]==host) or (referer and referer.split('://',1)[-1].split('/',1)[0]==host)
        if not valid:
            return JSONResponse({'detail':'CSRF protection rejected this request'},status_code=403)
    response=await call_next(request)
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['X-Frame-Options']='DENY'
    response.headers['Referrer-Policy']='strict-origin-when-cross-origin'
    response.headers['Permissions-Policy']='camera=(self), geolocation=(), microphone=()'
    response.headers['Content-Security-Policy']="default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    if os.getenv('SESSION_HTTPS_ONLY','true').lower()=='true': response.headers['Strict-Transport-Security']='max-age=31536000; includeSubDomains'
    return response


def db():
    s=SessionLocal()
    try: yield s
    finally: s.close()


def current_user(request:Request,db:Session=Depends(db)):
    uid=request.session.get('uid')
    return db.get(User,uid) if uid else None


def role_required(user,roles):
    if not user or not user.active or user.role not in roles: raise HTTPException(403,'Not authorized')


def clean_text(value:str,max_len:int=5000,required=False):
    value=(value or '').strip()
    if required and not value: raise HTTPException(400,'Required field is empty')
    if len(value)>max_len: raise HTTPException(400,'Input is too long')
    return value


def unique_code(prefix): return f'{prefix}-{uuid.uuid4().hex[:12].upper()}'


def seed():
    """Seed master data only. User creation requires explicit bootstrap environment variables."""
    dbs=SessionLocal()
    try:
        admin_user=os.getenv('BOOTSTRAP_ADMIN_USERNAME','').strip()
        admin_password=os.getenv('BOOTSTRAP_ADMIN_PASSWORD','')
        admin_name=os.getenv('BOOTSTRAP_ADMIN_FULL_NAME','System Administrator').strip() or 'System Administrator'
        if admin_user and admin_password:
            existing_admin=dbs.scalar(select(User).where(User.username==admin_user))
            if existing_admin:
                existing_admin.full_name=admin_name; existing_admin.password_hash=hash_password(admin_password); existing_admin.role='ADMIN'; existing_admin.active=True
            else:
                dbs.add(User(username=admin_user,full_name=admin_name,password_hash=hash_password(admin_password),role='ADMIN'))
            dbs.commit()
        if not dbs.scalar(select(Floor).where(Floor.number==2)):
            dbs.add_all([Floor(number=i,name=f'{i}th Floor') for i in range(2,6)]); dbs.commit()
        floors={f.number:f for f in dbs.scalars(select(Floor)).all()}
        existing_rooms={r.room_number:r for r in dbs.scalars(select(Room)).all()}
        for n in range(201,301):
            if n not in existing_rooms:
                floor_num=2+(n-201)//25
                dbs.add(Room(floor_id=floors[floor_num].id,room_number=n,status='Available'))
        dbs.commit()
        areas=['Buduchalley','Sillanto','Fura','Executive','Mitima','Odako','Gudumale','Bubble','Bubbles','Fura Corridor','Executive Meeting Room','Counter']
        existing={a.name for a in dbs.scalars(select(Area)).all()}
        for x in areas:
            if x not in existing: dbs.add(Area(name=x,department='F&B' if x=='Buduchalley' else 'Unknown'))
        items=['Light','Switch','Window','Door Key','Door Lock','Paint','Mirror','Drainage Cover','Frame','Background Frame','Spot Light','Plumbing','AC','Electrical','Sling','Jemison Frame','Corridor Paint','Drainage Line Cover','Switch Cover','Stage Light Switch Separation','Other']
        existing={i.name for i in dbs.scalars(select(WorkingItem)).all()}
        for x in items:
            if x not in existing: dbs.add(WorkingItem(name=x))
        cats=['Electrical','Plumbing','HVAC','Painting','Carpentry','Civil','Safety','General','Other']
        existing={c.name for c in dbs.scalars(select(Category)).all()}
        for x in cats:
            if x not in existing: dbs.add(Category(name=x))
        if not dbs.scalar(select(Checklist).where(Checklist.name=='Room Inspection')):
            c=Checklist(name='Room Inspection'); dbs.add(c); dbs.flush()
            dbs.add_all([ChecklistItem(checklist_id=c.id,name=x,sort_order=i) for i,x in enumerate(['Lights','Switches','Door Lock','Water Supply','Toilet','AC','Window','Mirror','Plumbing','Safety Equipment'])])
        if not dbs.scalar(select(InventoryItem).where(InventoryItem.part_code=='LED-001')):
            dbs.add(InventoryItem(part_code='LED-001',part_name='LED Bulb',quantity=48,minimum_stock=10,unit='pcs',unit_cost=150))
        settings={'hotel_name':os.getenv('HOTEL_NAME','Hotel Maintenance Management System'),'currency':os.getenv('CURRENCY','ETB'),'monthly_budget':'50000','budget_alert_threshold':'80'}
        for k,v in settings.items():
            if not dbs.scalar(select(Setting).where(Setting.key==k)): dbs.add(Setting(key=k,value=v))
        dbs.commit()
        if not dbs.scalar(select(MaintenanceRequest).limit(1)):
            seed_note(dbs)
        rooms=dbs.scalars(select(Room)).all(); areas_rows=dbs.scalars(select(Area)).all(); existing_qr={q.code for q in dbs.scalars(select(QRCode)).all()}
        for r in rooms:
            if f'ROOM-{r.room_number}' not in existing_qr: dbs.add(QRCode(code=f'ROOM-{r.room_number}',location_type='Room',room_id=r.id))
        for a in areas_rows:
            if f'AREA-{a.id}' not in existing_qr: dbs.add(QRCode(code=f'AREA-{a.id}',location_type='Hotel Area',area_id=a.id))
        dbs.commit()
    finally: dbs.close()


def seed_note(dbs):
    admin=dbs.scalar(select(User).order_by(User.id));
    if not admin: return
    areas={a.name:a for a in dbs.scalars(select(Area)).all()}; items={i.name:i for i in dbs.scalars(select(WorkingItem)).all()}; cats={c.name:c for c in dbs.scalars(select(Category)).all()}
    records=[('Sling',['Buduchalley'],'F&B'),('Jemison Frame',['Sillanto'],'Unknown'),('Window',['Sillanto'],'Unknown'),('Paint',['Sillanto','Fura','Executive'],'Unknown'),('Background Frame',['Executive'],'Unknown'),('Door Key',['Mitima'],'Unknown'),('Corridor Paint',['Fura Corridor'],'Unknown'),('Light',['Executive Meeting Room','Gudumale','Counter','Bubbles'],'Unknown'),('Cracked Mirror',['Executive Meeting Room','Gudumale','Counter','Bubbles'],'Unknown'),('Drainage Line Cover',['Executive Meeting Room','Gudumale','Counter','Bubbles'],'Unknown'),('Switch Cover',['Odako'],'Unknown'),('Stage Light Switch Separation',['Odako','Gudumale'],'Unknown'),('Counter Paint / Spot Light',['Bubble'],'Unknown')]
    for item,locs,dept in records:
        wi=items.get(item) or items.get('Other')
        for loc in locs:
            dbs.add(MaintenanceRequest(request_code=unique_code('SEED'),location_type='Hotel Area',area_id=areas[loc].id,working_item_id=wi.id,category_id=cats['General'].id,problem=f'Original maintenance note 07/12/18: {item}',priority='MEDIUM',status='Pending',requested_by_id=admin.id,due_at=sla_due('MEDIUM'),notes=f'Department: {dept}; Source note date: 07/12/18; Authorized By: Signed; Requested By / Done By: Blank / Pending'))
    dbs.commit()


@app.get('/login',response_class=HTMLResponse)
def login_page(request:Request): return templates.TemplateResponse(request,'login.html',{})

@app.post('/login')
def login(request:Request,username:str=Form(...),password:str=Form(...),db:Session=Depends(db)):
    ip=request.client.host if request.client else 'unknown'; now=utcnow().timestamp(); attempts=[x for x in login_attempts.get(ip,[]) if now-x<LOGIN_WINDOW]
    if len(attempts)>=LOGIN_MAX: raise HTTPException(429,'Too many login attempts. Try again later.')
    u=db.scalar(select(User).where(User.username==username.strip()))
    if not u or not u.active or not verify_password(password,u.password_hash):
        attempts.append(now); login_attempts[ip]=attempts; return templates.TemplateResponse(request,'login.html',{'error':'Invalid username or password'},status_code=401)
    login_attempts.pop(ip,None); request.session.clear(); request.session['uid']=u.id; audit(db,u,'LOGIN','User',u.id,new='success',ip=ip); db.commit(); return RedirectResponse('/',303)

@app.post('/logout')
def logout(request:Request,user=Depends(current_user),db:Session=Depends(db)):
    if user: audit(db,user,'LOGOUT','User',user.id,ip=request.client.host if request.client else ''); db.commit()
    request.session.clear(); return RedirectResponse('/login',303)

@app.get('/',response_class=HTMLResponse)
def dashboard(request:Request,user=Depends(current_user),db:Session=Depends(db)):
    if not user:return RedirectResponse('/login',303)
    base=select(MaintenanceRequest)
    if user.role=='EMPLOYEE': base=base.where(MaintenanceRequest.requested_by_id==user.id)
    if user.role=='MAINTENANCE STAFF': base=base.where(MaintenanceRequest.assigned_to_id==user.id)
    reqs=db.scalars(base).all(); now=utcnow()
    total=len(reqs)
    stats={'total':total,'pending':sum(r.status=='Pending' for r in reqs),'progress':sum(r.status=='In Progress' for r in reqs),'completed':sum(r.status in ('Completed','Verified','Closed') for r in reqs),'overdue':sum(r.status not in ('Completed','Verified','Closed','Cancelled') and r.due_at<now for r in reqs),'urgent':sum(r.priority=='URGENT' for r in reqs),'rooms':db.scalar(select(func.count(Room.id))) or 0,'oos':db.scalar(select(func.count(Room.id)).where(Room.status.in_(['Maintenance','Out of Service']))) or 0,'lowstock':db.scalar(select(func.count(InventoryItem.id)).where(InventoryItem.quantity<=InventoryItem.minimum_stock)) or 0}
    if user.role=='ADMIN': stats['users']=db.scalar(select(func.count(User.id))) or 0; stats['cost']=sum(c.total for c in db.scalars(select(Cost)).all())
    if user.role in ('ADMIN','MANAGER'): stats['sla_compliance']=round((total-stats['overdue'])/total*100,1) if total else 100
    return templates.TemplateResponse(request,'dashboard.html',{'user':user,'stats':stats,'recent':reqs[-10:][::-1]})

@app.get('/requests',response_class=HTMLResponse)
def requests(request:Request,user=Depends(current_user),db:Session=Depends(db)):
    if not user:return RedirectResponse('/login',303)
    q=select(MaintenanceRequest).order_by(desc(MaintenanceRequest.created_at))
    if user.role=='EMPLOYEE':q=q.where(MaintenanceRequest.requested_by_id==user.id)
    if user.role=='MAINTENANCE STAFF':q=q.where(MaintenanceRequest.assigned_to_id==user.id)
    rows=db.scalars(q).all(); qr_room=None; qr_area=None; qr_code=request.session.pop('qr_code',None)
    if qr_code:
        qr=db.scalar(select(QRCode).where(QRCode.code==qr_code,QRCode.status=='Active')); qr_room=qr.room_id if qr and qr.location_type=='Room' else None; qr_area=qr.area_id if qr and qr.location_type=='Hotel Area' else None
    return templates.TemplateResponse(request,'requests.html',{'user':user,'rows':rows,'rooms':db.scalars(select(Room).order_by(Room.room_number)).all(),'areas':db.scalars(select(Area).where(Area.status=='Active').order_by(Area.name)).all(),'items':db.scalars(select(WorkingItem).where(WorkingItem.active.is_(True)).order_by(WorkingItem.name)).all(),'cats':db.scalars(select(Category).where(Category.active.is_(True)).order_by(Category.name)).all(),'qr_room':qr_room,'qr_area':qr_area})

@app.post('/api/requests')
def api_create_request(request:Request,payload:dict,user=Depends(current_user),db:Session=Depends(db)):
    if not user: raise HTTPException(401)
    if request is None: raise HTTPException(400)
    if request.headers.get('x-offline-queue')!='1': raise HTTPException(403,'Offline queue header required')
    try:
        location_type=str(payload.get('location_type','')); room_id=int(payload['room_id']) if payload.get('room_id') else None; area_id=int(payload['area_id']) if payload.get('area_id') else None; working_item_id=int(payload['working_item_id']); category_id=int(payload['category_id']); priority=str(payload.get('priority','')).upper(); problem=clean_text(str(payload.get('problem','')),5000,True); client_request_id=clean_text(str(payload.get('client_request_id','')),80,True)
    except (KeyError,ValueError,TypeError): raise HTTPException(400,'Invalid request payload')
    if db.scalar(select(MaintenanceRequest).where(MaintenanceRequest.client_request_id==client_request_id)): return JSONResponse({'ok':True,'duplicate':True},status_code=200)
    if location_type=='Room':
        room=db.get(Room,room_id)
        if not room or not 201<=room.room_number<=300: raise HTTPException(400,'Invalid room')
        floor_id=room.floor_id; area_id=None
    elif location_type=='Hotel Area':
        area=db.get(Area,area_id)
        if not area or area.status!='Active': raise HTTPException(400,'Invalid area')
        floor_id=None; room_id=None
    else: raise HTTPException(400,'Invalid location type')
    if priority not in PRIORITIES or not db.get(WorkingItem,working_item_id) or not db.get(Category,category_id): raise HTTPException(400,'Invalid request values')
    r=MaintenanceRequest(request_code=unique_code('MR'),client_request_id=client_request_id,location_type=location_type,floor_id=floor_id,room_id=room_id,area_id=area_id,working_item_id=working_item_id,category_id=category_id,problem=problem,priority=priority,status='Pending',requested_by_id=user.id,due_at=sla_due(priority)); db.add(r); db.flush(); db.add(RequestStatusHistory(request_id=r.id,old_status='',new_status='Pending',changed_by_id=user.id)); notify_roles(db,['MANAGER','ADMIN'],f'New {priority} maintenance request {r.request_code}','NEW_REQUEST',r.id); audit(db,user,'CREATE','MaintenanceRequest',r.id,new=problem); db.commit(); return JSONResponse({'ok':True,'request_code':r.request_code})

@app.post('/requests/create')
def create_request(request:Request,location_type:str=Form(...),room_id:int|None=Form(None),area_id:int|None=Form(None),working_item_id:int=Form(...),category_id:int=Form(...),problem:str=Form(...),priority:str=Form(...),client_request_id:str|None=Form(None),user=Depends(current_user),db:Session=Depends(db)):
    if not user:return RedirectResponse('/login',303)
    location_type=location_type.strip(); priority=priority.upper(); problem=clean_text(problem,5000,True)
    if priority not in PRIORITIES or location_type not in ('Room','Hotel Area'): raise HTTPException(400,'Invalid request values')
    if client_request_id:
        existing=db.scalar(select(MaintenanceRequest).where(MaintenanceRequest.client_request_id==client_request_id));
        if existing:return RedirectResponse('/requests',303)
    wi=db.get(WorkingItem,working_item_id); cat=db.get(Category,category_id)
    if not wi or not wi.active or not cat or not cat.active: raise HTTPException(400,'Invalid working item or category')
    if location_type=='Room':
        room=db.get(Room,room_id) if room_id else None
        if not room or not 201<=room.room_number<=300: raise HTTPException(400,'Invalid room')
        floor_id=room.floor_id; area_id=None
    else:
        area=db.get(Area,area_id) if area_id else None
        if not area or area.status!='Active': raise HTTPException(400,'Invalid area')
        floor_id=None; room_id=None
    r=MaintenanceRequest(request_code=unique_code('MR'),client_request_id=client_request_id,location_type=location_type,floor_id=floor_id,room_id=room_id,area_id=area_id,working_item_id=wi.id,category_id=cat.id,problem=problem,priority=priority,status='Pending',requested_by_id=user.id,due_at=sla_due(priority))
    db.add(r); db.flush(); db.add(RequestStatusHistory(request_id=r.id,old_status='',new_status='Pending',changed_by_id=user.id)); notify_roles(db,['MANAGER','ADMIN'],f'New {priority} maintenance request {r.request_code}','NEW_REQUEST',r.id); audit(db,user,'CREATE','MaintenanceRequest',r.id,new=problem,ip=request.client.host if request.client else ''); db.commit(); return RedirectResponse('/requests',303)

@app.post('/requests/{rid}/approve')
def approve_request(rid:int,user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN','MANAGER']); r=db.get(MaintenanceRequest,rid)
    if not r: raise HTTPException(404)
    if r.status!='Pending': raise HTTPException(409,'Only pending requests can be approved')
    old=r.status; wo=WorkOrder(work_order_code=unique_code('WO'),request_id=r.id,due_at=r.due_at,status='Assigned'); db.add(wo); db.flush(); record_request_status(db,r,old,'Approved',user,'Manager approval'); db.add(Notification(user_id=user.id,message=f'Work order {wo.work_order_code} created',type='WORK_ORDER',request_id=r.id,work_order_id=wo.id)); notify_roles(db,['MAINTENANCE STAFF'],f'Work order created for {r.request_code}','WORK_ORDER',r.id,wo.id); audit(db,user,'APPROVAL','MaintenanceRequest',r.id,old=old,new='Approved'); db.commit(); return RedirectResponse('/work-orders',303)

@app.get('/work-orders',response_class=HTMLResponse)
def work_orders(request:Request,user=Depends(current_user),db:Session=Depends(db)):
    if not user:return RedirectResponse('/login',303)
    q=select(WorkOrder).order_by(desc(WorkOrder.id))
    if user.role=='MAINTENANCE STAFF': q=q.where(WorkOrder.assigned_staff_id==user.id)
    if user.role=='EMPLOYEE': q=q.where(WorkOrder.request.has(MaintenanceRequest.requested_by_id==user.id))
    rows=db.scalars(q).all(); staff=db.scalars(select(User).where(User.role=='MAINTENANCE STAFF',User.active.is_(True))).all(); parts=db.scalars(select(InventoryItem).where(InventoryItem.status=='Active').order_by(InventoryItem.part_name)).all()
    return templates.TemplateResponse(request,'work_orders.html',{'user':user,'rows':rows,'staff':staff,'parts':parts})

@app.post('/work-orders/{wid}/assign')
def assign_wo(wid:int,staff_id:int=Form(...),user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN','MANAGER']); wo=db.get(WorkOrder,wid); staff=db.get(User,staff_id)
    if not wo or not staff or staff.role!='MAINTENANCE STAFF' or not staff.active:raise HTTPException(400,'Invalid assignment')
    old=wo.request.status; wo.assigned_staff_id=staff.id; wo.request.assigned_to_id=staff.id; wo.status='Assigned'; record_request_status(db,wo.request,old,'Assigned',user,'Work order assigned'); db.add(Notification(user_id=staff.id,message=f'Assigned {wo.work_order_code}',type='ASSIGNMENT',work_order_id=wo.id,request_id=wo.request_id)); audit(db,user,'ASSIGNMENT','WorkOrder',wo.id,new=staff.username); db.commit(); return RedirectResponse('/work-orders',303)

@app.post('/work-orders/{wid}/status')
def wo_status(wid:int,status:str=Form(...),work_performed:str=Form(''),completion_notes:str=Form(''),labor_hours:float=Form(0),user=Depends(current_user),db:Session=Depends(db)):
    if not user:return RedirectResponse('/login',303)
    wo=db.get(WorkOrder,wid)
    if not wo: raise HTTPException(404)
    if user.role=='MAINTENANCE STAFF' and wo.assigned_staff_id!=user.id: raise HTTPException(403)
    if user.role=='EMPLOYEE': raise HTTPException(403)
    if status not in ('In Progress','Completed'): raise HTTPException(400,'Invalid status')
    if labor_hours<0 or labor_hours>1000: raise HTTPException(400,'Invalid labor hours')
    if status=='Completed' and not clean_text(work_performed,5000,True): raise HTTPException(400,'Work performed is required')
    old=wo.status; wo.status=status; wo.work_performed=clean_text(work_performed); wo.completion_notes=clean_text(completion_notes); wo.labor_hours=labor_hours
    if status=='In Progress': record_request_status(db,wo.request,wo.request.status,'In Progress',user)
    if status=='Completed': wo.completed_by_id=user.id; wo.completed_at=utcnow(); wo.request.completed_at=utcnow(); record_request_status(db,wo.request,wo.request.status,'Completed',user)
    audit(db,user,'STATUS_CHANGE','WorkOrder',wo.id,old=old,new=status); db.commit(); return RedirectResponse('/work-orders',303)

@app.post('/work-orders/{wid}/verify')
def verify_wo(wid:int,passed:str=Form(...),user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN','MANAGER']); wo=db.get(WorkOrder,wid)
    if not wo:raise HTTPException(404)
    if wo.status!='Completed': raise HTTPException(409,'Work order must be completed before verification')
    old=wo.request.status
    if passed=='yes':wo.status='Verified'; wo.verified_by_id=user.id; wo.verification_at=utcnow(); record_request_status(db,wo.request,old,'Closed',user,'Verification passed')
    elif passed=='no':wo.status='In Progress'; record_request_status(db,wo.request,old,'In Progress',user,'Verification failed')
    else: raise HTTPException(400,'Invalid verification result')
    audit(db,user,'VERIFICATION','WorkOrder',wo.id,old=old,new=wo.request.status); db.commit(); return RedirectResponse('/work-orders',303)

@app.post('/work-orders/{wid}/parts')
def use_part(wid:int,part_id:int=Form(...),quantity:float=Form(...),user=Depends(current_user),db:Session=Depends(db)):
    if not user:return RedirectResponse('/login',303)
    wo=db.get(WorkOrder,wid); part=db.get(InventoryItem,part_id)
    if not wo or not part:raise HTTPException(404)
    if user.role not in ['ADMIN','MANAGER','MAINTENANCE STAFF']:raise HTTPException(403)
    if user.role=='MAINTENANCE STAFF' and wo.assigned_staff_id!=user.id:raise HTTPException(403)
    try: recalc_inventory(db,part,quantity,user,wo,wo.request,'Work order usage')
    except ValueError as e: raise HTTPException(400,str(e))
    audit(db,user,'INVENTORY_CHANGE','InventoryItem',part.id,new=f'OUT {quantity}'); db.commit(); return RedirectResponse('/work-orders',303)


def validate_upload(data:bytes,ext:str):
    if len(data)>MAX_UPLOAD: raise HTTPException(400,'File too large')
    signatures={'.pdf':data.startswith(b'%PDF-'),'.png':data.startswith(b'\x89PNG\r\n\x1a\n'),'.jpg':data.startswith(b'\xff\xd8\xff'),'.jpeg':data.startswith(b'\xff\xd8\xff'),'.webp':data.startswith(b'RIFF') and data[8:12]==b'WEBP', '.docx':data.startswith(b'PK\x03\x04'),'.xlsx':data.startswith(b'PK\x03\x04'),'.csv':True,'.doc':data.startswith(b'\xd0\xcf\x11\xe0')}
    if ext not in signatures or not signatures[ext]: raise HTTPException(400,'File content does not match extension')
    if ext in {'.jpg','.jpeg','.png','.webp'}:
        try:
            from PIL import Image
            Image.open(io.BytesIO(data)).verify()
        except Exception: raise HTTPException(400,'Invalid image')

@app.post('/upload/{wid}')
async def upload(wid:int,file:UploadFile=File(...),kind:str=Form('Evidence'),user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN','MANAGER','MAINTENANCE STAFF'])
    if kind not in ALLOWED_FILE_KINDS: raise HTTPException(400,'Invalid attachment type')
    wo=db.get(WorkOrder,wid)
    if not wo: raise HTTPException(404)
    if user.role=='MAINTENANCE STAFF' and wo.assigned_staff_id!=user.id: raise HTTPException(403)
    data=await file.read(); ext=Path(file.filename or '').suffix.lower(); validate_upload(data,ext)
    safe_name=f'{uuid.uuid4().hex}{ext}'; (UPLOADS/safe_name).write_bytes(data)
    db.add(Attachment(work_order_id=wid,request_id=wo.request_id,file_name=Path(file.filename or safe_name).name[:255],stored_path=safe_name,file_type=kind,file_size=len(data),uploaded_by_id=user.id)); audit(db,user,'CREATE','Attachment',wid,new=kind); db.commit(); return RedirectResponse('/work-orders',303)

@app.get('/attachments/{aid}')
def download_attachment(aid:int,user=Depends(current_user),db:Session=Depends(db)):
    if not user: raise HTTPException(401)
    a=db.get(Attachment,aid)
    if not a: raise HTTPException(404)
    allowed=False
    if user.role in ('ADMIN','MANAGER'): allowed=True
    elif a.uploaded_by_id==user.id: allowed=True
    elif a.work_order_id:
        wo=db.get(WorkOrder,a.work_order_id); allowed=bool(wo and wo.assigned_staff_id==user.id)
    if not allowed: raise HTTPException(403)
    path=UPLOADS/a.stored_path
    if not path.is_file() or path.parent.resolve()!=UPLOADS.resolve(): raise HTTPException(404)
    return FileResponse(path,filename=Path(a.file_name).name,media_type=mimetypes.guess_type(a.file_name)[0] or 'application/octet-stream')

@app.get('/inventory',response_class=HTMLResponse)
def inventory(request:Request,user=Depends(current_user),db:Session=Depends(db)):
    if not user:return RedirectResponse('/login',303)
    return templates.TemplateResponse(request,'inventory.html',{'user':user,'rows':db.scalars(select(InventoryItem).order_by(InventoryItem.part_name)).all()})

@app.post('/inventory')
def add_inventory(part_name:str=Form(...),quantity:float=Form(...),minimum_stock:float=Form(...),unit_cost:float=Form(...),unit:str=Form('pcs'),user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN','MANAGER'])
    if quantity<0 or minimum_stock<0 or unit_cost<0: raise HTTPException(400,'Inventory values cannot be negative')
    part_name=clean_text(part_name,160,True); unit=clean_text(unit,30,True)
    code=unique_code('PART'); db.add(InventoryItem(part_code=code,part_name=part_name,quantity=quantity,minimum_stock=minimum_stock,unit_cost=unit_cost,unit=unit)); audit(db,user,'CREATE','InventoryItem',code); db.commit(); return RedirectResponse('/inventory',303)

@app.get('/reports',response_class=HTMLResponse)
def reports(request:Request,user=Depends(current_user),db:Session=Depends(db)):
    if not user:return RedirectResponse('/login',303)
    cats=db.execute(select(Category.name,func.count(MaintenanceRequest.id)).join(MaintenanceRequest,MaintenanceRequest.category_id==Category.id,isouter=True).group_by(Category.name)).all(); floors=db.execute(select(Floor.number,func.count(MaintenanceRequest.id)).join(MaintenanceRequest,MaintenanceRequest.floor_id==Floor.id,isouter=True).group_by(Floor.number)).all(); costs=db.scalars(select(Cost)).all(); total_cost=sum(c.total for c in costs)
    return templates.TemplateResponse(request,'reports.html',{'user':user,'cats':cats,'floors':floors,'total_cost':total_cost})

@app.get('/reports/requests.csv')
def requests_csv(user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN','MANAGER']); rows=db.scalars(select(MaintenanceRequest).order_by(MaintenanceRequest.created_at)).all(); out=io.StringIO(); w=csv.writer(out); w.writerow(['Request ID','Location','Priority','Status','Created','Due'])
    for r in rows:w.writerow([r.request_code,r.location_type,r.priority,r.status,r.created_at.isoformat(),r.due_at.isoformat()])
    return StreamingResponse(iter([out.getvalue()]),media_type='text/csv',headers={'Content-Disposition':'attachment; filename=maintenance_requests.csv'})

@app.get('/admin',response_class=HTMLResponse)
def admin_page(request:Request,user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN']); return templates.TemplateResponse(request,'admin.html',{'user':user,'users':db.scalars(select(User).order_by(User.username)).all(),'rooms':db.scalars(select(Room).order_by(Room.room_number)).all(),'areas':db.scalars(select(Area).order_by(Area.name)).all(),'backups':sorted([p.name for p in BACKUPS.glob('*.db')])})

@app.post('/admin/room-status/{rid}')
def room_status(rid:int,status:str=Form(...),reason:str=Form(''),user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN','MANAGER']); room=db.get(Room,rid)
    if not room or status not in ROOM_STATUSES:raise HTTPException(400,'Invalid room/status')
    if status in ('Maintenance','Out of Service') and not clean_text(reason,1000,True): raise HTTPException(400,'Reason is required')
    old=room.status; room.status=status; db.add(RoomBlockingHistory(room_id=room.id,status=status,reason=clean_text(reason,1000),created_by_id=user.id)); audit(db,user,'ROOM_STATUS_CHANGE','Room',rid,old,new=status); db.commit(); return RedirectResponse('/admin',303)

@app.get('/qr/{code}.png')
def qr_png(code:str,db:Session=Depends(db)):
    qr=db.scalar(select(QRCode).where(QRCode.code==code,QRCode.status=='Active'))
    if not qr:raise HTTPException(404)
    img=qrcode.make(f'/qr/{code}'); b=io.BytesIO(); img.save(b,format='PNG'); b.seek(0); return StreamingResponse(b,media_type='image/png')

@app.get('/qr/{code}')
def qr_landing(request:Request,code:str,db:Session=Depends(db)):
    qr=db.scalar(select(QRCode).where(QRCode.code==code,QRCode.status=='Active'))
    if not qr:raise HTTPException(404)
    request.session['qr_code']=code; return RedirectResponse('/requests',303)

@app.get('/api/rooms')
def api_rooms(user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN','MANAGER','MAINTENANCE STAFF','EMPLOYEE']); return [{'id':r.id,'room_number':r.room_number,'floor':r.floor.number,'status':r.status} for r in db.scalars(select(Room).order_by(Room.room_number)).all()]

@app.get('/api/notifications')
def api_notifications(user=Depends(current_user),db:Session=Depends(db)):
    if not user:raise HTTPException(401)
    return [{'id':n.id,'message':n.message,'type':n.type,'read':n.read,'created_at':n.created_at.isoformat()} for n in db.scalars(select(Notification).where(Notification.user_id==user.id).order_by(desc(Notification.created_at)).limit(50)).all()]

@app.post('/notifications/{nid}/read')
def mark_read(nid:int,user=Depends(current_user),db:Session=Depends(db)):
    if not user:raise HTTPException(401)
    n=db.get(Notification,nid)
    if not n or n.user_id!=user.id:raise HTTPException(404)
    n.read=True; db.commit(); return JSONResponse({'ok':True})

@app.post('/backup')
def backup(user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN'])
    ts=utcnow().strftime('%Y%m%d_%H%M%S'); target=BACKUPS/f'hotel_maintenance_{ts}.db';
    if not str(engine.url).startswith('sqlite'): raise HTTPException(400,'Built-in backup endpoint supports SQLite only; use managed database backups for production PostgreSQL.')
    source=sqlite3.connect(str(engine.url.database)); dest=sqlite3.connect(target); source.backup(dest); dest.close(); source.close(); audit(db,user,'BACKUP','Database',target.name); db.commit(); return RedirectResponse('/admin',303)

@app.get('/backup/{filename}')
def download_backup(filename:str,user=Depends(current_user)):
    role_required(user,['ADMIN']); path=BACKUPS/Path(filename).name
    if not path.is_file():raise HTTPException(404)
    return FileResponse(path,filename=path.name,media_type='application/octet-stream')

@app.post('/restore')
def restore(filename:str=Form(...),user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN']); src=BACKUPS/Path(filename).name
    if not src.exists() or src.suffix!='.db':raise HTTPException(404,'Backup not found')
    current=Path(str(engine.url.database)).resolve(); safety=BACKUPS/f'pre_restore_{utcnow().strftime("%Y%m%d_%H%M%S")}.db'
    engine.dispose(); shutil.copy2(current,safety); shutil.copy2(src,current)
    audit_db=SessionLocal(); audit_db.add(AuditLog(user_id=user.id,action='RESTORE',object_type='Database',object_id=src.name,old_value=safety.name,new_value='restored')); audit_db.commit(); audit_db.close(); return RedirectResponse('/admin',303)

@app.get('/preventive',response_class=HTMLResponse)
def preventive(request:Request,user=Depends(current_user),db:Session=Depends(db)):
    if not user:return RedirectResponse('/login',303)
    rows=db.scalars(select(PreventiveTask).order_by(PreventiveTask.next_due_at)).all(); return templates.TemplateResponse(request,'preventive.html',{'user':user,'rows':rows,'rooms':db.scalars(select(Room).order_by(Room.room_number)).all(),'areas':db.scalars(select(Area).where(Area.status=='Active')).all(),'staff':db.scalars(select(User).where(User.role=='MAINTENANCE STAFF',User.active.is_(True))).all()})

@app.post('/preventive')
def create_preventive(location_type:str=Form(...),room_id:int|None=Form(None),area_id:int|None=Form(None),task:str=Form(...),frequency:str=Form(...),priority:str=Form('MEDIUM'),next_due_at:str=Form(...),user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN','MANAGER']);
    if location_type not in ('Room','Hotel Area') or frequency not in ALLOWED_FREQUENCIES or priority.upper() not in PRIORITIES:raise HTTPException(400,'Invalid preventive maintenance values')
    if location_type=='Room' and not db.get(Room,room_id):raise HTTPException(400,'Invalid room')
    if location_type=='Hotel Area' and not db.get(Area,area_id):raise HTTPException(400,'Invalid area')
    try: due=datetime.fromisoformat(next_due_at)
    except ValueError: raise HTTPException(400,'Invalid date')
    db.add(PreventiveTask(location_type=location_type,room_id=room_id if location_type=='Room' else None,area_id=area_id if location_type=='Hotel Area' else None,task=clean_text(task,250,True),frequency=frequency,priority=priority.upper(),next_due_at=due,status='Scheduled')); db.commit(); return RedirectResponse('/preventive',303)

@app.get('/checklists',response_class=HTMLResponse)
def checklists(request:Request,user=Depends(current_user),db:Session=Depends(db)):
    if not user:return RedirectResponse('/login',303)
    checks=db.scalars(select(Checklist).where(Checklist.active.is_(True))).all(); items=db.scalars(select(ChecklistItem).where(ChecklistItem.checklist_id==checks[0].id).order_by(ChecklistItem.sort_order)).all() if checks else []
    return templates.TemplateResponse(request,'checklists.html',{'user':user,'checklists':checks,'items':items,'rooms':db.scalars(select(Room).order_by(Room.room_number)).all(),'areas':db.scalars(select(Area).where(Area.status=='Active')).all()})

@app.post('/inspections')
def create_inspection(checklist_id:int=Form(...),room_id:int|None=Form(None),area_id:int|None=Form(None),result_json:str=Form(...),notes:str=Form(''),user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN','MANAGER','MAINTENANCE STAFF']);
    checklist=db.get(Checklist,checklist_id)
    if not checklist:raise HTTPException(400,'Invalid checklist')
    if bool(room_id)==bool(area_id):raise HTTPException(400,'Select exactly one location')
    if room_id and not db.get(Room,room_id):raise HTTPException(400,'Invalid room')
    if area_id and not db.get(Area,area_id):raise HTTPException(400,'Invalid area')
    try: payload=json.loads(result_json)
    except json.JSONDecodeError:raise HTTPException(400,'Invalid checklist result')
    valid_items={i.id for i in db.scalars(select(ChecklistItem).where(ChecklistItem.checklist_id==checklist_id)).all()}
    if not isinstance(payload,list) or not payload:raise HTTPException(400,'Checklist results required')
    ins=Inspection(checklist_id=checklist_id,room_id=room_id,area_id=area_id,inspector_id=user.id,notes=clean_text(notes,5000)); db.add(ins); db.flush(); fails=0
    for x in payload:
        item_id=int(x['item_id']); status=x['status']
        if item_id not in valid_items or status not in ('Pass','Fail','N/A'):raise HTTPException(400,'Invalid checklist item/result')
        if status=='Fail':fails+=1
        db.add(InspectionResult(inspection_id=ins.id,checklist_item_id=item_id,status=status,notes=clean_text(x.get('notes',''),1000)))
    db.flush()
    if fails:
        wi=db.scalar(select(WorkingItem).where(WorkingItem.name=='Other')) or db.scalar(select(WorkingItem)); cat=db.scalar(select(Category).where(Category.name=='General')) or db.scalar(select(Category)); floor_id=db.get(Room,room_id).floor_id if room_id else None
        r=MaintenanceRequest(request_code=unique_code('INSP'),location_type='Room' if room_id else 'Hotel Area',floor_id=floor_id,room_id=room_id,area_id=area_id,working_item_id=wi.id,category_id=cat.id,problem='Checklist inspection failed',priority='MEDIUM',status='Pending',requested_by_id=user.id,due_at=sla_due('MEDIUM'),notes=f'{fails} checklist item(s) failed'); db.add(r); db.flush(); db.add(RequestStatusHistory(request_id=r.id,old_status='',new_status='Pending',changed_by_id=user.id)); notify_roles(db,['MANAGER','ADMIN'],'Inspection failure created a maintenance request','NEW_REQUEST',r.id)
    audit(db,user,'CREATE','Inspection',ins.id,new=f'fails={fails}'); db.commit(); return RedirectResponse('/checklists',303)

@app.get('/qr',response_class=HTMLResponse)
def qr_page(request:Request,user=Depends(current_user),db:Session=Depends(db)):
    if not user:return RedirectResponse('/login',303)
    role_required(user,['ADMIN','MANAGER','MAINTENANCE STAFF','EMPLOYEE']); rows=db.scalars(select(QRCode).order_by(QRCode.code)).all(); return templates.TemplateResponse(request,'qr.html',{'user':user,'rows':rows})

@app.get('/notifications',response_class=HTMLResponse)
def notifications_page(request:Request,user=Depends(current_user),db:Session=Depends(db)):
    if not user:return RedirectResponse('/login',303)
    rows=db.scalars(select(Notification).where(Notification.user_id==user.id).order_by(desc(Notification.created_at))).all(); return templates.TemplateResponse(request,'notifications.html',{'user':user,'rows':rows})

@app.get('/audit',response_class=HTMLResponse)
def audit_page(request:Request,user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN']); rows=db.scalars(select(AuditLog).order_by(desc(AuditLog.timestamp)).limit(300)).all(); return templates.TemplateResponse(request,'audit.html',{'user':user,'rows':rows})

@app.get('/suppliers',response_class=HTMLResponse)
def suppliers_page(request:Request,user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN','MANAGER']); return templates.TemplateResponse(request,'suppliers.html',{'user':user,'suppliers':db.scalars(select(Supplier).order_by(Supplier.company_name)).all(),'contractors':db.scalars(select(Contractor).order_by(Contractor.name)).all()})

@app.post('/suppliers')
def add_supplier(company_name:str=Form(...),contact_person:str=Form(''),phone:str=Form(''),email:str=Form(''),user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN','MANAGER']); db.add(Supplier(company_name=clean_text(company_name,180,True),contact_person=clean_text(contact_person,120),phone=clean_text(phone,50),email=clean_text(email,160))); db.commit(); return RedirectResponse('/suppliers',303)

@app.post('/contractors')
def add_contractor(name:str=Form(...),service_type:str=Form(''),phone:str=Form(''),rate:float=Form(0),user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN','MANAGER']);
    if rate<0:raise HTTPException(400,'Invalid rate')
    db.add(Contractor(name=clean_text(name,180,True),service_type=clean_text(service_type,120),phone=clean_text(phone,50),rate=rate)); db.commit(); return RedirectResponse('/suppliers',303)

@app.post('/costs/{wid}')
def add_cost(wid:int,parts_cost:float=Form(0),labor_cost:float=Form(0),contractor_cost:float=Form(0),transport_cost:float=Form(0),other_cost:float=Form(0),user=Depends(current_user),db:Session=Depends(db)):
    role_required(user,['ADMIN','MANAGER','MAINTENANCE STAFF']); wo=db.get(WorkOrder,wid)
    if not wo:raise HTTPException(404)
    values=[parts_cost,labor_cost,contractor_cost,transport_cost,other_cost]
    if any(x<0 for x in values):raise HTTPException(400,'Costs cannot be negative')
    if user.role=='MAINTENANCE STAFF' and wo.assigned_staff_id!=user.id:raise HTTPException(403)
    c=Cost(request_id=wo.request_id,work_order_id=wid,parts_cost=parts_cost,labor_cost=labor_cost,contractor_cost=contractor_cost,transport_cost=transport_cost,other_cost=other_cost); db.add(c); audit(db,user,'COST_CHANGE','WorkOrder',wid,new=c.total); db.commit(); return RedirectResponse('/work-orders',303)

@app.get('/api/push/public-key')
def push_public_key():
    return {'enabled':bool(os.getenv('VAPID_PUBLIC_KEY')),'public_key':os.getenv('VAPID_PUBLIC_KEY','')}

@app.post('/api/push/subscribe')
def push_subscribe(payload:dict,user=Depends(current_user),db:Session=Depends(db)):
    if not user:raise HTTPException(401)
    endpoint=str(payload.get('endpoint','')).strip(); keys=payload.get('keys') or {}
    if not endpoint or not keys.get('p256dh') or not keys.get('auth'):raise HTTPException(400,'Invalid push subscription')
    sub=db.scalar(select(PushSubscription).where(PushSubscription.endpoint==endpoint))
    if sub: sub.user_id=user.id; sub.p256dh=keys['p256dh']; sub.auth=keys['auth']
    else: db.add(PushSubscription(user_id=user.id,endpoint=endpoint,p256dh=keys['p256dh'],auth=keys['auth']))
    db.commit(); return {'ok':True}

@app.delete('/api/push/subscribe')
def push_unsubscribe(payload:dict,user=Depends(current_user),db:Session=Depends(db)):
    if not user:raise HTTPException(401)
    endpoint=str(payload.get('endpoint','')).strip(); sub=db.scalar(select(PushSubscription).where(PushSubscription.endpoint==endpoint,PushSubscription.user_id==user.id))
    if sub:db.delete(sub);db.commit()
    return {'ok':True}

@app.get('/health')
def health(db:Session=Depends(db)):
    db.execute(select(func.count(User.id))).scalar_one(); return {'status':'ok','service':'hotel-maintenance'}
