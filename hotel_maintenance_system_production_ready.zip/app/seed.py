from .main import seed
seed(); print('Seed complete')
