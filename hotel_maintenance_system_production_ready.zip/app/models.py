from datetime import datetime, timezone
from sqlalchemy import String, Integer, DateTime, Date, Boolean, ForeignKey, Float, Text, UniqueConstraint, Index
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

class Base(DeclarativeBase): pass

def now(): return datetime.now(timezone.utc).replace(tzinfo=None)

class User(Base):
    __tablename__='users'
    id: Mapped[int]=mapped_column(primary_key=True)
    username: Mapped[str]=mapped_column(String(80), unique=True, index=True)
    full_name: Mapped[str]=mapped_column(String(160))
    password_hash: Mapped[str]=mapped_column(String(300))
    role: Mapped[str]=mapped_column(String(30), index=True)
    active: Mapped[bool]=mapped_column(Boolean, default=True)
    created_at: Mapped[datetime]=mapped_column(DateTime, default=now)

class Floor(Base):
    __tablename__='floors'
    id: Mapped[int]=mapped_column(primary_key=True)
    number: Mapped[int]=mapped_column(Integer, unique=True)
    name: Mapped[str]=mapped_column(String(80))
    active: Mapped[bool]=mapped_column(Boolean, default=True)
    rooms=relationship('Room', back_populates='floor')

class Room(Base):
    __tablename__='rooms'
    id: Mapped[int]=mapped_column(primary_key=True)
    floor_id: Mapped[int]=mapped_column(ForeignKey('floors.id'), index=True)
    room_number: Mapped[int]=mapped_column(Integer, unique=True, index=True)
    status: Mapped[str]=mapped_column(String(30), default='Available', index=True)
    created_at: Mapped[datetime]=mapped_column(DateTime, default=now)
    updated_at: Mapped[datetime]=mapped_column(DateTime, default=now, onupdate=now)
    floor=relationship('Floor', back_populates='rooms')

class Area(Base):
    __tablename__='areas'
    id: Mapped[int]=mapped_column(primary_key=True)
    name: Mapped[str]=mapped_column(String(120), unique=True, index=True)
    department: Mapped[str]=mapped_column(String(120), default='')
    description: Mapped[str]=mapped_column(Text, default='')
    status: Mapped[str]=mapped_column(String(30), default='Active')
    created_at: Mapped[datetime]=mapped_column(DateTime, default=now)
    updated_at: Mapped[datetime]=mapped_column(DateTime, default=now, onupdate=now)

class WorkingItem(Base):
    __tablename__='working_items'
    id: Mapped[int]=mapped_column(primary_key=True)
    name: Mapped[str]=mapped_column(String(120), unique=True)
    active: Mapped[bool]=mapped_column(Boolean, default=True)

class Category(Base):
    __tablename__='categories'
    id: Mapped[int]=mapped_column(primary_key=True)
    name: Mapped[str]=mapped_column(String(80), unique=True)
    active: Mapped[bool]=mapped_column(Boolean, default=True)

class MaintenanceRequest(Base):
    __tablename__='maintenance_requests'
    id: Mapped[int]=mapped_column(primary_key=True)
    request_code: Mapped[str]=mapped_column(String(30), unique=True, index=True)
    client_request_id: Mapped[str|None]=mapped_column(String(80), unique=True, nullable=True, index=True)
    location_type: Mapped[str]=mapped_column(String(20))
    floor_id: Mapped[int|None]=mapped_column(ForeignKey('floors.id'), nullable=True, index=True)
    room_id: Mapped[int|None]=mapped_column(ForeignKey('rooms.id'), nullable=True, index=True)
    area_id: Mapped[int|None]=mapped_column(ForeignKey('areas.id'), nullable=True, index=True)
    working_item_id: Mapped[int]=mapped_column(ForeignKey('working_items.id'))
    category_id: Mapped[int]=mapped_column(ForeignKey('categories.id'))
    problem: Mapped[str]=mapped_column(Text)
    priority: Mapped[str]=mapped_column(String(20), index=True)
    status: Mapped[str]=mapped_column(String(30), default='Pending', index=True)
    requested_by_id: Mapped[int]=mapped_column(ForeignKey('users.id'))
    assigned_to_id: Mapped[int|None]=mapped_column(ForeignKey('users.id'), nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime, default=now, index=True)
    updated_at: Mapped[datetime]=mapped_column(DateTime, default=now, onupdate=now)
    due_at: Mapped[datetime]=mapped_column(DateTime, index=True)
    completed_at: Mapped[datetime|None]=mapped_column(DateTime, nullable=True)
    notes: Mapped[str]=mapped_column(Text, default='')
    room=relationship('Room'); area=relationship('Area'); requested_by=relationship('User', foreign_keys=[requested_by_id]); assigned_to=relationship('User', foreign_keys=[assigned_to_id])

class WorkOrder(Base):
    __tablename__='work_orders'
    id: Mapped[int]=mapped_column(primary_key=True)
    work_order_code: Mapped[str]=mapped_column(String(30), unique=True, index=True)
    request_id: Mapped[int]=mapped_column(ForeignKey('maintenance_requests.id'), unique=True)
    assigned_staff_id: Mapped[int|None]=mapped_column(ForeignKey('users.id'), nullable=True)
    contractor_id: Mapped[int|None]=mapped_column(ForeignKey('contractors.id'), nullable=True)
    status: Mapped[str]=mapped_column(String(30), default='Assigned', index=True)
    due_at: Mapped[datetime]
    work_performed: Mapped[str]=mapped_column(Text, default='')
    completion_notes: Mapped[str]=mapped_column(Text, default='')
    labor_hours: Mapped[float]=mapped_column(Float, default=0)
    completed_by_id: Mapped[int|None]=mapped_column(ForeignKey('users.id'), nullable=True)
    completed_at: Mapped[datetime|None]=mapped_column(DateTime, nullable=True)
    verified_by_id: Mapped[int|None]=mapped_column(ForeignKey('users.id'), nullable=True)
    verification_at: Mapped[datetime|None]=mapped_column(DateTime, nullable=True)
    request=relationship('MaintenanceRequest')

class PreventiveTask(Base):
    __tablename__='preventive_tasks'
    id: Mapped[int]=mapped_column(primary_key=True)
    location_type: Mapped[str]=mapped_column(String(20))
    room_id: Mapped[int|None]=mapped_column(ForeignKey('rooms.id'), nullable=True)
    area_id: Mapped[int|None]=mapped_column(ForeignKey('areas.id'), nullable=True)
    task: Mapped[str]=mapped_column(String(250))
    assigned_staff_id: Mapped[int|None]=mapped_column(ForeignKey('users.id'), nullable=True)
    frequency: Mapped[str]=mapped_column(String(20))
    priority: Mapped[str]=mapped_column(String(20), default='Medium')
    next_due_at: Mapped[datetime]=mapped_column(DateTime, index=True)
    status: Mapped[str]=mapped_column(String(30), default='Scheduled')
    notes: Mapped[str]=mapped_column(Text, default='')

class Checklist(Base):
    __tablename__='checklists'
    id: Mapped[int]=mapped_column(primary_key=True)
    name: Mapped[str]=mapped_column(String(160), unique=True)
    active: Mapped[bool]=mapped_column(Boolean, default=True)

class ChecklistItem(Base):
    __tablename__='checklist_items'
    id: Mapped[int]=mapped_column(primary_key=True)
    checklist_id: Mapped[int]=mapped_column(ForeignKey('checklists.id'), index=True)
    name: Mapped[str]=mapped_column(String(160))
    sort_order: Mapped[int]=mapped_column(Integer, default=0)

class Inspection(Base):
    __tablename__='inspections'
    id: Mapped[int]=mapped_column(primary_key=True)
    checklist_id: Mapped[int]=mapped_column(ForeignKey('checklists.id'))
    room_id: Mapped[int|None]=mapped_column(ForeignKey('rooms.id'), nullable=True)
    area_id: Mapped[int|None]=mapped_column(ForeignKey('areas.id'), nullable=True)
    inspector_id: Mapped[int]=mapped_column(ForeignKey('users.id'))
    inspected_at: Mapped[datetime]=mapped_column(DateTime, default=now)
    notes: Mapped[str]=mapped_column(Text, default='')

class InspectionResult(Base):
    __tablename__='inspection_results'
    id: Mapped[int]=mapped_column(primary_key=True)
    inspection_id: Mapped[int]=mapped_column(ForeignKey('inspections.id'), index=True)
    checklist_item_id: Mapped[int]=mapped_column(ForeignKey('checklist_items.id'))
    status: Mapped[str]=mapped_column(String(10))
    notes: Mapped[str]=mapped_column(Text, default='')

class Supplier(Base):
    __tablename__='suppliers'
    id: Mapped[int]=mapped_column(primary_key=True)
    company_name: Mapped[str]=mapped_column(String(180), unique=True)
    contact_person: Mapped[str]=mapped_column(String(120), default='')
    phone: Mapped[str]=mapped_column(String(50), default='')
    email: Mapped[str]=mapped_column(String(160), default='')
    address: Mapped[str]=mapped_column(Text, default='')
    status: Mapped[str]=mapped_column(String(30), default='Active')
    notes: Mapped[str]=mapped_column(Text, default='')

class Contractor(Base):
    __tablename__='contractors'
    id: Mapped[int]=mapped_column(primary_key=True)
    name: Mapped[str]=mapped_column(String(180), unique=True)
    service_type: Mapped[str]=mapped_column(String(120), default='')
    phone: Mapped[str]=mapped_column(String(50), default='')
    email: Mapped[str]=mapped_column(String(160), default='')
    rate: Mapped[float]=mapped_column(Float, default=0)
    status: Mapped[str]=mapped_column(String(30), default='Active')
    notes: Mapped[str]=mapped_column(Text, default='')

class InventoryItem(Base):
    __tablename__='inventory_items'
    id: Mapped[int]=mapped_column(primary_key=True)
    part_code: Mapped[str]=mapped_column(String(40), unique=True)
    part_name: Mapped[str]=mapped_column(String(160), index=True)
    category: Mapped[str]=mapped_column(String(100), default='General')
    quantity: Mapped[float]=mapped_column(Float, default=0)
    minimum_stock: Mapped[float]=mapped_column(Float, default=0)
    unit: Mapped[str]=mapped_column(String(30), default='pcs')
    unit_cost: Mapped[float]=mapped_column(Float, default=0)
    supplier_id: Mapped[int|None]=mapped_column(ForeignKey('suppliers.id'), nullable=True)
    storage_location: Mapped[str]=mapped_column(String(160), default='')
    status: Mapped[str]=mapped_column(String(30), default='Active')
    supplier=relationship('Supplier')

class StockMovement(Base):
    __tablename__='stock_movements'
    id: Mapped[int]=mapped_column(primary_key=True)
    part_id: Mapped[int]=mapped_column(ForeignKey('inventory_items.id'), index=True)
    direction: Mapped[str]=mapped_column(String(10))
    quantity: Mapped[float]
    request_id: Mapped[int|None]=mapped_column(ForeignKey('maintenance_requests.id'), nullable=True)
    work_order_id: Mapped[int|None]=mapped_column(ForeignKey('work_orders.id'), nullable=True)
    user_id: Mapped[int]=mapped_column(ForeignKey('users.id'))
    reason: Mapped[str]=mapped_column(Text, default='')
    created_at: Mapped[datetime]=mapped_column(DateTime, default=now)

class Cost(Base):
    __tablename__='costs'
    id: Mapped[int]=mapped_column(primary_key=True)
    request_id: Mapped[int|None]=mapped_column(ForeignKey('maintenance_requests.id'), nullable=True)
    work_order_id: Mapped[int|None]=mapped_column(ForeignKey('work_orders.id'), nullable=True)
    parts_cost: Mapped[float]=mapped_column(Float, default=0)
    labor_cost: Mapped[float]=mapped_column(Float, default=0)
    contractor_cost: Mapped[float]=mapped_column(Float, default=0)
    transport_cost: Mapped[float]=mapped_column(Float, default=0)
    other_cost: Mapped[float]=mapped_column(Float, default=0)
    created_at: Mapped[datetime]=mapped_column(DateTime, default=now)
    @property
    def total(self): return sum([self.parts_cost,self.labor_cost,self.contractor_cost,self.transport_cost,self.other_cost])

class Attachment(Base):
    __tablename__='attachments'
    id: Mapped[int]=mapped_column(primary_key=True)
    request_id: Mapped[int|None]=mapped_column(ForeignKey('maintenance_requests.id'), nullable=True)
    work_order_id: Mapped[int|None]=mapped_column(ForeignKey('work_orders.id'), nullable=True)
    file_name: Mapped[str]=mapped_column(String(255))
    stored_path: Mapped[str]=mapped_column(String(500))
    file_type: Mapped[str]=mapped_column(String(50))
    file_size: Mapped[int]=mapped_column(Integer)
    uploaded_by_id: Mapped[int]=mapped_column(ForeignKey('users.id'))
    created_at: Mapped[datetime]=mapped_column(DateTime, default=now)

class QRCode(Base):
    __tablename__='qr_codes'
    id: Mapped[int]=mapped_column(primary_key=True)
    code: Mapped[str]=mapped_column(String(80), unique=True, index=True)
    location_type: Mapped[str]=mapped_column(String(20))
    room_id: Mapped[int|None]=mapped_column(ForeignKey('rooms.id'), nullable=True)
    area_id: Mapped[int|None]=mapped_column(ForeignKey('areas.id'), nullable=True)
    status: Mapped[str]=mapped_column(String(20), default='Active')
    created_at: Mapped[datetime]=mapped_column(DateTime, default=now)

class Notification(Base):
    __tablename__='notifications'
    id: Mapped[int]=mapped_column(primary_key=True)
    user_id: Mapped[int]=mapped_column(ForeignKey('users.id'), index=True)
    message: Mapped[str]=mapped_column(String(500))
    type: Mapped[str]=mapped_column(String(50))
    request_id: Mapped[int|None]=mapped_column(ForeignKey('maintenance_requests.id'), nullable=True)
    work_order_id: Mapped[int|None]=mapped_column(ForeignKey('work_orders.id'), nullable=True)
    read: Mapped[bool]=mapped_column(Boolean, default=False)
    created_at: Mapped[datetime]=mapped_column(DateTime, default=now, index=True)

class AuditLog(Base):
    __tablename__='audit_logs'
    id: Mapped[int]=mapped_column(primary_key=True)
    user_id: Mapped[int|None]=mapped_column(ForeignKey('users.id'), nullable=True)
    action: Mapped[str]=mapped_column(String(80), index=True)
    object_type: Mapped[str]=mapped_column(String(80), index=True)
    object_id: Mapped[str]=mapped_column(String(80), default='')
    old_value: Mapped[str]=mapped_column(Text, default='')
    new_value: Mapped[str]=mapped_column(Text, default='')
    ip: Mapped[str]=mapped_column(String(80), default='')
    timestamp: Mapped[datetime]=mapped_column(DateTime, default=now, index=True)

class RoomBlockingHistory(Base):
    __tablename__='room_blocking_history'
    id: Mapped[int]=mapped_column(primary_key=True)
    room_id: Mapped[int]=mapped_column(ForeignKey('rooms.id'), index=True)
    status: Mapped[str]=mapped_column(String(30))
    reason: Mapped[str]=mapped_column(Text)
    start_date: Mapped[datetime]=mapped_column(DateTime, default=now)
    expected_return_date: Mapped[datetime|None]=mapped_column(DateTime, nullable=True)
    work_order_id: Mapped[int|None]=mapped_column(ForeignKey('work_orders.id'), nullable=True)
    ended_at: Mapped[datetime|None]=mapped_column(DateTime, nullable=True)
    created_by_id: Mapped[int]=mapped_column(ForeignKey('users.id'))

class RequestStatusHistory(Base):
    __tablename__='request_status_history'
    id: Mapped[int]=mapped_column(primary_key=True)
    request_id: Mapped[int]=mapped_column(ForeignKey('maintenance_requests.id'), index=True)
    old_status: Mapped[str]=mapped_column(String(30), default='')
    new_status: Mapped[str]=mapped_column(String(30))
    changed_by_id: Mapped[int]=mapped_column(ForeignKey('users.id'))
    changed_at: Mapped[datetime]=mapped_column(DateTime, default=now, index=True)
    note: Mapped[str]=mapped_column(Text, default='')

class PushSubscription(Base):
    __tablename__='push_subscriptions'
    id: Mapped[int]=mapped_column(primary_key=True)
    user_id: Mapped[int]=mapped_column(ForeignKey('users.id'), index=True)
    endpoint: Mapped[str]=mapped_column(Text, unique=True)
    p256dh: Mapped[str]=mapped_column(Text)
    auth: Mapped[str]=mapped_column(Text)
    created_at: Mapped[datetime]=mapped_column(DateTime, default=now)
    updated_at: Mapped[datetime]=mapped_column(DateTime, default=now, onupdate=now)

class Setting(Base):
    __tablename__='settings'
    id: Mapped[int]=mapped_column(primary_key=True)
    key: Mapped[str]=mapped_column(String(100), unique=True)
    value: Mapped[str]=mapped_column(Text, default='')

Index('ix_requests_status_priority_created','maintenance_requests.status','maintenance_requests.priority','maintenance_requests.created_at')
