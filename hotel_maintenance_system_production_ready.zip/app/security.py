import hashlib
import hmac
import os
import secrets
from itsdangerous import URLSafeSerializer


def _secret() -> str:
    value = os.getenv('APP_SECRET', '').strip()
    if not value or len(value) < 32:
        raise RuntimeError('APP_SECRET must be set and contain at least 32 characters.')
    return value


def hash_password(password: str) -> str:
    if len(password) < 12:
        raise ValueError('Password must be at least 12 characters.')
    salt = secrets.token_bytes(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
    return salt.hex() + ':' + dk.hex()


def verify_password(password: str, stored: str) -> bool:
    try:
        salt_hex, dk_hex = stored.split(':', 1)
        actual = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt_hex), n=2**14, r=8, p=1)
        return hmac.compare_digest(actual, bytes.fromhex(dk_hex))
    except Exception:
        return False


def make_session(user_id: int):
    return URLSafeSerializer(_secret(), salt='hotel-session').dumps({'uid': user_id})


def read_session(value: str):
    try:
        return URLSafeSerializer(_secret(), salt='hotel-session').loads(value).get('uid')
    except Exception:
        return None
