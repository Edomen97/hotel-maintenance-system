# Hotel Maintenance Management System

Production-oriented FastAPI + SQLAlchemy hotel maintenance platform with relational data, role-based access control, audit logging, QR workflows, inventory, work orders, preventive maintenance, secure evidence uploads, backups, PWA/offline request queuing and optional Web Push.

## Main stack

- Python 3.13+
- FastAPI
- SQLAlchemy 2.x
- Alembic migrations
- SQLite for small deployments; PostgreSQL recommended for production
- Jinja2 responsive UI
- Service Worker + IndexedDB offline queue
- Optional VAPID Web Push via `pywebpush`

## First deployment

1. Create a virtual environment and install dependencies.
2. Copy `.env.example` to `.env` or provide the variables through the process/container secret manager.
3. Set a random `APP_SECRET` of at least 32 characters.
4. Set `BOOTSTRAP_ADMIN_USERNAME`, `BOOTSTRAP_ADMIN_PASSWORD` and `BOOTSTRAP_ADMIN_FULL_NAME` for the first administrator only.
5. Run `alembic upgrade head`.
6. Run `python -m app.seed` once to seed floors, rooms, master data, QR codes and the supplied maintenance note.
7. Remove or rotate the bootstrap password variables after the administrator account has been created.
8. Start the server with `python run.py` behind HTTPS.

Example:

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# edit .env and supply real secrets
alembic upgrade head
python -m app.seed
python run.py
```

## Room data

The database contains exactly 100 guest rooms numbered 201 through 300. Room-floor relationships are stored in the `rooms.floor_id` foreign key. The seed allocation is:

- 201–225 → floor 2
- 226–250 → floor 3
- 251–275 → floor 4
- 276–300 → floor 5

The application does not accept arbitrary room numbers in maintenance requests.

## Authentication and roles

No demo/default passwords are shipped. Passwords are stored using salted `scrypt` hashes. Roles are ADMIN, MANAGER, MAINTENANCE STAFF and EMPLOYEE. Sensitive actions are authorization-checked server-side.

## Security

Production deployments should use HTTPS, `SESSION_HTTPS_ONLY=true`, a strong secret manager, PostgreSQL, a reverse proxy/WAF, secure object storage for evidence files, centralized logs and external database backups. POST requests are protected by same-origin CSRF checks, sessions are rotated at login, login attempts are throttled, security headers are applied, and uploaded files are validated by content signature and image parsing.

Evidence files are not exposed as a public static directory. They are served through an authenticated attachment endpoint.

## Offline/PWA

The browser can queue maintenance request form submissions in IndexedDB when offline. Each queued request has a client-generated idempotency key, so reconnect/sync does not create duplicates. The queue flushes when connectivity returns. The Service Worker caches the application shell.

## Web Push

Web Push is optional. Configure `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY` and `VAPID_CLAIMS_EMAIL`. Generate VAPID credentials using a trusted deployment process and never commit the private key. If these variables are absent, in-app notifications continue to work and push is disabled.

## Backup and restore

The built-in backup/restore flow is intended for SQLite. It creates a database snapshot and a safety copy before restore, and records the operation in the audit log. For PostgreSQL production deployments, use managed/PITR backups instead.

## Tests

```bash
pytest -q
```

The suite verifies room integrity, floor mapping, authentication and permissions, request validation and SLA, request → work order workflow, inventory deduction, low-stock notifications, QR mapping, upload validation, dashboard availability, backups and Alembic migrations.
